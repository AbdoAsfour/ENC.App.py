def enc(w,k,a):
    count = len(w)
    ciphered = ""
    
    if a == "enc":
        for i in range(count):
            current= ord(w[i])
            current+=int(k)
            ciphered+=chr(current)
        return ciphered
    elif a == "dec":
        for i in range(count):
            current= ord(w[i])
            current-=int(k)
            ciphered+=chr(current)
        return ciphered
    else:
        print("what is this!!")