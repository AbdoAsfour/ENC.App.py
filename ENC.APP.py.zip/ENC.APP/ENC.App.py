from CREnc import enc
from tkinter import *
from tkinter import ttk
enc1= Tk()
enc1.geometry('500x420+500+100')
enc1.resizable(False,False)
enc1.title('Encyption and Decryption')
enc1.config(background='green')

fr1= Frame(width='500',height='420',bg='blue')
fr1.place(x=1,y=1)

lb= Label(fr1,text='welcame in Encyption program',fg='black',bg='blue',font=550,width=25,height=5)
lb.place(x=150,y=5)

lb2= Label(fr1,text='in',fg='black',bg='blue',font=550)
lb2.place(x=80,y=117)

lb3= Label(fr1,text='out',fg='black',bg='blue',font=550)
lb3.place(x=80,y=145)

com= ttk.Combobox(fr1,values=('enc','dec'),state='readonly')
com.place(x=350,y=200)

ent= Entry(fr1,justify='center',fg='black',bg='red',width=30)
ent.place(x=150,y=120)
ent1= Entry(fr1,justify='center',fg='black',bg='red',width=30)
ent1.place(x=150,y=150)

sp= Spinbox(fr1,from_=0,to=100,background='red')
sp.place(x=150,y=200)
def first():
    x= ent.get()
    k= sp.get()
    a= com.get()
    
    ciphered=enc(x,k,a)
    ent1.insert(0,ciphered)

def delet():
    ent1.delete(0,END)
    ent.delete(0,END)
    sp.delete(0,END)

but1=Button(fr1,text='start',fg='black',bg='red',width='25',height='2',cursor='man',command=first)
but1.place(x=150,y=330)

but2=Button(fr1,text='clear',fg='black',bg='red',width='25',height='2', cursor='no',command=delet)
but2.place(x=150,y=370)

menus= Menu(fr1)
f=Menu(menus,tearoff=0,background='red')
f.add_command(label='new')
f.add_command(label='new1')
f.add_separator()
f.add_command(label='new2',command=enc1.quit)
menus.add_cascade(label='file',menu=f)
enc1.config(menu=menus,background='red')

enc1.mainloop()